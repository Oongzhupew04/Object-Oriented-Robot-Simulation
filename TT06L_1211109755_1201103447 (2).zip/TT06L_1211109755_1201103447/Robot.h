/**********|**********|**********|
Program: Robot.h
Course: CCP6124-OOPDS
Trimester: 2410
Name: VINCENT OONG ZHU PEW
ID: 1211109755
Email: 1211109755@student.mmu.edu.my
Phone: 018-2891578
Name: SHANTANA VENKEDESWAR A/L KARTHEGESU
ID: 1201103447
Email: 1201103447@student.mmu.edu.my
Phone: 012-3225265
Lecture Section: TC2L
Tutorial Section: TT6L
**********|**********|**********/

#pragma once

#include <iostream>
#include <string>
#include <list>
#include "Battlefield.h"
#include "ReadFile.h"
#include "Queue.h"

using namespace std;

template <class T>
class LinkedList;

class Robot
{
    private:
        string name;
        int xpos;
        int ypos;
        string symbol;
        int howManyKill = 0;
        int BlueThunderCount;
        int enemy_x;
        int enemy_y;
    public:

        virtual void action(Robot* &botptr, ReadFile &demo1, Battlefield &map, string symbol, int x, int y, Queue &revive, LinkedList<Robot*> &robotslst, ofstream &outFile) = 0;
        Robot();
        // no default constructor
        Robot(Robot* &botptr, ReadFile &demo1, Battlefield &map, string name, string symbol, int x, int y, Queue &revive, LinkedList<Robot*> &robotslst, ofstream &outFile);
        void setRobot(Battlefield &map, string name, string symbol, int x, int y, Queue &revive, LinkedList<Robot*> &robotslst, ofstream &outFile);

        string getName();

        string getSymbol();

        int getxpos();

        int getypos();

        void updatePosition(int position_x, int position_y);

        void updateKill();

        int getNumKill();

        int getBlueThunderCount();

        void setBlueThunderCount(int i);

        void setenemy_x(int enemyx);

        int getenemy_x();

        void setenemy_y(int enemyy);

        int getenemy_y();

};

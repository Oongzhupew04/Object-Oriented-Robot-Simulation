/**********|**********|**********|
Program: Queue.cpp
Course: CCP6124-OOPDS
Trimester: 2410
Name: VINCENT OONG ZHU PEW
ID: 1211109755
Email: 1211109755@student.mmu.edu.my
Phone: 018-2891578
Name: SHANTANA VENKEDESWAR A/L KARTHEGESU
ID: 1201103447
Email: 1201103447@student.mmu.edu.my
Phone: 012-3225265
Lecture Section: TC2L
Tutorial Section: TT6L
**********|**********|**********/

#include "Queue.h"
#include "LinkedList.h"
#include "Robot.h"
#include "Battlefield.h"
#include "ReadFile.h"

#include <sstream>
using namespace std;

Queue::Queue(int c)
{
    size = 0;
    capacity = c;
    front = -1;
    back = -1;
    queue = new char[capacity];
}

bool Queue::full()
{
    if(size == capacity)
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool Queue::empty()
{
    if(size == 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}

char Queue::first()
{
    if(empty())
    {
        return '\0'; 
    }
    else
    {
        return queue[front];
    }
}

Queue::~Queue()
{
    delete[]queue;
}

void Queue::push(char robot)
{
    if(full())
    {
        return;
    }

    if(size == 0)
    {
        front = 0;
        back = 0;
        queue[back] = robot;
    }
    else
    {
        back = (back + 1) % capacity;
        queue[back] = robot;
    }
    size++;
}

void Queue::pop()
{
    if(empty())
    {
        return;
    }
    else
    {
        front = (front + 1) % capacity;
        size--;
    }
}

void Queue::removeDeadRobot(ReadFile &demo1, Battlefield &map, char robot, Queue &revive, LinkedList<Robot*> &robotslst, ofstream &outFile)
{
    int live;
    if(robot == '@')
        {
            BTlive--;
            live = BTlive;
        }
        else if(robot == '#')
        {
            Tlive--;
            live = Tlive;
        }
        else if(robot == '$')
        {
            RClive--;
            live = RClive;
        }
        else if(robot == '%')
        {
            TRClive--;
            live = TRClive;
        }
        else if(robot == '&')
        {
            Mlive--;
            live = Mlive;
        }
        else if(robot == '0')
        {
            RTlive--;
            live = RTlive;
        }
        else if(robot == '?')
        {
            URlive--;
            live = URlive;
        }

    if(live == 0)
    {
        stringstream ss;
        ss << robot;
        string str = ss.str();
        robotslst.deleterobot(str);
        map.removeRobots(robot);
    }
    else
    {
        step = 0;
        push(robot);
        stringstream ss;
        ss << robot;
        string str = ss.str();
        string name = robotslst.getrobotname(str);
        robotslst.deleterobot(str);
        map.removeRobots(robot);
        robotslst.setRespawn(demo1, map, str, revive, robotslst, name, outFile);
    }
}

void Queue::increaseStep()
{
    step++;
}
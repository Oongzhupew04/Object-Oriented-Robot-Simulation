/**********|**********|**********|
Program: SteppingRobot.h
Course: CCP6124-OOPDS
Trimester: 2410
Name: VINCENT OONG ZHU PEW
ID: 1211109755
Email: 1211109755@student.mmu.edu.my
Phone: 018-2891578
Name: SHANTANA VENKEDESWAR A/L KARTHEGESU
ID: 1201103447
Email: 1201103447@student.mmu.edu.my
Phone: 012-3225265
Lecture Section: TC2L
Tutorial Section: TT6L
**********|**********|**********/

#pragma once

#include <iostream>
#include "Robot.h"
using namespace std;

class SteppingRobot : public virtual Robot
{
    public:
    SteppingRobot(Robot* &botptr, ReadFile &demo1, Battlefield &map, string name, string symbol, int x, int y, Queue &revive, LinkedList<Robot*> &robotslst, ofstream &outFile):Robot(botptr, demo1, map, name, symbol, x,y, revive, robotslst, outFile){}
        virtual void action(Robot* &botptr, ReadFile &demo1, Battlefield &map, string symbol, int x, int y, Queue &revive, LinkedList<Robot*> &robotslst, ofstream &outFile) = 0;
        virtual void step(Robot* &botptr, ReadFile &demo1, Battlefield &map, string symbol, int x, int y, Queue &revive, LinkedList<Robot*> &robotslst, ofstream &outFile) = 0;
};


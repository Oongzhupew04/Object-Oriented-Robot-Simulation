/**********|**********|**********|
Program: ReadFile.cpp
Course: CCP6124-OOPDS
Trimester: 2410
Name: VINCENT OONG ZHU PEW
ID: 1211109755
Email: 1211109755@student.mmu.edu.my
Phone: 018-2891578
Name: SHANTANA VENKEDESWAR A/L KARTHEGESU
ID: 1201103447
Email: 1201103447@student.mmu.edu.my
Phone: 012-3225265
Lecture Section: TC2L
Tutorial Section: TT6L
**********|**********|**********/

#include "ReadFile.h"
using namespace std;

ReadFile::ReadFile(ofstream &outFile, string inputs)
{
    {
        string filename = inputs;
        input.open(filename);

        if (!input.is_open())
        {
            cerr << "Error: Unable to open file " << filename << endl;
            exit(1);
        }

        string line, tempString;

        // Get M and N
        getline(input, line);
        stringstream ss(line);
        ss >> tempString >> tempString >> tempString >> tempString; // Skip "M by N :"
        ss >> positionM >> positionN;
        setPositionM(positionM);
        setPositionN(positionN);
        setMxN(positionM, positionN);

        // Get steps
        ss.clear();
        getline(input, line);
        ss.str(line);
        ss >> tempString >> robotStep; // Skip steps:


        // Get RobotNumber
        ss.clear();
        getline(input, line);
        ss.str(line);
        ss >> tempString >> robotNumber;

        cout << "ROBOT SYMBOLS: " << endl;
        cout << "\033[34mBlueThunder = @\033[0m" << endl;
        cout << "\033[33mTerminator = #\033[0m" << endl;
        cout << "\033[31mRoboCop = $\033[0m" << endl;
        cout << "\033[36mTerminatorRoboCop = %\033[0m" << endl;
        cout << "\033[35mMadbot = &\033[0m" << endl;
        cout << "\033[37mRoboTank = 0\033[0m" << endl;
        cout << "\033[30mUltimateRobot = ?\033[0m" << endl;
        cout << "Shots = *" << endl << endl;
        outFile << "ROBOT SYMBOLS: " << endl;
        outFile << "BlueThunder = @" << endl;
        outFile << "Terminator = #" << endl;
        outFile << "RoboCop = $" << endl;
        outFile << "TerminatorRoboCop = %" << endl;
        outFile << "Madbot = &" << endl;
        outFile << "RoboTank = 0" << endl;
        outFile << "UltimateRobot = ?" << endl;
        outFile << "Shots = *" << endl << endl;


        cout << "ROBOT INFORMATION: " << endl;
        outFile << "ROBOT INFORMATION: " << endl;
        cout << "M:" << getPositionM() << " N:" << getPositionN() << endl;
        outFile << "M:" << getPositionM() << " N:" << getPositionN() << endl;
        cout << "Step:" << robotStep << endl;
        outFile << "Step:" << robotStep << endl;
        cout << "Robot numbers:" << robotNumber << endl;
        outFile << "Robot numbers:" << robotNumber << endl;

        // Cout RobotDetails
        for (int i = 0; i < robotNumber; i++)
        {
            getline(input, line);
            stringstream ss(line);
            ss >> robotType >> robotName >> robotPosM >> robotPosN;
            cout << robotType << " " << robotName << " " << robotPosM << " " << robotPosN << " " << endl;
            outFile << robotType << " " << robotName << " " << robotPosM << " " << robotPosN << " " << endl;
        }
        cout << endl;
        outFile << endl;
        input.close();
    }
}
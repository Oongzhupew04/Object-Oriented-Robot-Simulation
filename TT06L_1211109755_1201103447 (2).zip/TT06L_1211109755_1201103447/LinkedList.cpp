/**********|**********|**********|
Program: LinkedList.tpp
Course: CCP6124-OOPDS
Trimester: 2410
Name: VINCENT OONG ZHU PEW
ID: 1211109755
Email: 1211109755@student.mmu.edu.my
Phone: 018-2891578
Name: SHANTANA VENKEDESWAR A/L KARTHEGESU
ID: 1201103447
Email: 1201103447@student.mmu.edu.my
Phone: 012-3225265
Lecture Section: TC2L
Tutorial Section: TT6L
**********|**********|**********/

#include "LinkedList.h"
#include "Robot.h"
#include "ReadFile.h"
#include "Queue.h"


#include "RoboCop.h"
#include "Terminator.h"
#include "BlueThunder.h"
#include "TerminatorRoboCop.h"
#include "Madbot.h"
#include "RoboTank.h"
#include "UltimateRobot.h"

using namespace std;

template <class T>
LinkedList<T>::LinkedList()
{
    head = nullptr;
}

template <class T>
LinkedList<T>::~LinkedList() 
{
    Node<T>* current = head;
    while (current != nullptr) {
        Node<T>* next = current->next;
        delete current;
        current = next;
    }
}

template <class T>
void LinkedList<T>::push_back(T value)
{
    Node<T>* newrobots = getNode(value);
    if(head == nullptr)
    {
        head = newrobots;
    }
    else
    {
        getEnd()->next = newrobots;
        newrobots->next = nullptr;
    }
}

template <class T>
Node<T>* LinkedList<T>::getNode(T value)
{
    Node<T>* newrobots;
    newrobots = new Node<T>();
    newrobots->data = value;
    newrobots->next = nullptr;
    return newrobots;
}

template <class T>
Node<T>* LinkedList<T>::getEnd()
{
    Node<T>* turn = head;
    while(turn->next != nullptr)
    {
        turn = turn->next;
    }
    return turn;
}

template <class T>
void LinkedList<T>::deleterobot(string symbol)
{
    Node<T>* find = head;
    if(find->data->getSymbol() == symbol)   //If first node is the node to delete
    {
        head = head->next;
        delete find;
    }
    else
    {
        while(find->next->data->getSymbol() != symbol)
        {
            find = find->next;
        }
        if(find->next->next == nullptr)    //If last node is the node to delete
        {
            Node<T>* deleteptr = find->next;
            find->next = nullptr;
            delete deleteptr;
        }
        else
        {
            Node<T>* deleteptr = find->next;
            find->next = deleteptr->next;
            delete deleteptr;
        }
    }
}



template <class T>
void LinkedList<T>::print(ReadFile &demo1, Battlefield &map, Queue &revive, LinkedList<Robot*> &robotslst, ofstream &outFile)
{
    Node<T>* turn = head;
    string symbol;
    string robot_type;
    for(int i = 1; i <= demo1.getrobotStep(); i++)
    {
        Robot *botptr = turn->data;
        cout << "STEP: " << step << endl;
        outFile << "STEP: " << step << endl;
        turn->data->action(botptr, demo1, map, turn->data->getSymbol(), turn->data->getxpos(), turn->data->getypos(), revive, robotslst, outFile);
        cout << endl;
        outFile<< endl;
        map.display(turn->data->getSymbol(), turn->data->getxpos(), turn->data->getypos(), outFile);



        if(turn->data->getNumKill() == 3)
        {
            string newsymbol = turn->data->getSymbol();
            if(newsymbol == "@")
            {
                string upgradesymbol = "&";
                Robot *Mptr = new Madbot(Mptr, demo1, map, turn->data->getName(), upgradesymbol, turn->data->getxpos(), turn->data->getypos(), revive, robotslst, outFile);
                Mptr->setRobot(map, turn->data->getName(), upgradesymbol, turn->data->getxpos(), turn->data->getypos(), revive, robotslst, outFile);

                Node<T>* upgraderobots = getNode(Mptr);

                if(turn->next == nullptr)
                {
                    turn->next = upgraderobots;
                    upgraderobots->next = nullptr;
                    upgraderobots = nullptr;
                    turn = turn->next;
                    deleterobot(symbol);
                }
                else
                {
                    upgraderobots->next = turn->next;
                    turn->next = upgraderobots;
                    upgraderobots = nullptr;
                    turn = turn->next;
                    deleterobot(symbol);
                }
                cout << "BlueThunder has upgraded to Madbot" << endl;
                outFile << "BlueThunder has upgraded to Madbot" << endl;
            }
            else if(newsymbol == "#")
            {
                string upgradesymbol = "%";
                Robot *TRCptr = new TerminatorRoboCop(TRCptr, demo1, map, turn->data->getName(), upgradesymbol, turn->data->getxpos(), turn->data->getypos(), revive, robotslst, outFile);
                TRCptr->setRobot(map, turn->data->getName(), upgradesymbol, turn->data->getxpos(), turn->data->getypos(), revive, robotslst, outFile);

                Node<T>* upgraderobots = getNode(TRCptr);
                
                if(turn->next == nullptr)
                {
                    turn->next = upgraderobots;
                    upgraderobots->next = nullptr;
                    upgraderobots = nullptr;
                    turn = turn->next;
                    deleterobot(symbol);
                }
                else
                {
                    upgraderobots->next = turn->next;
                    turn->next = upgraderobots;
                    upgraderobots = nullptr;
                    turn = turn->next;
                    deleterobot(symbol);
                }
                cout << "Terminator has upgraded to TerminatorRoboCop" << endl;
                outFile << "Terminator has upgraded to TerminatorRoboCop" << endl;
            }
            else if(newsymbol == "$")
            {
                string upgradesymbol = "%";
                Robot *TRCptr = new TerminatorRoboCop(TRCptr, demo1, map, turn->data->getName(), upgradesymbol, turn->data->getxpos(), turn->data->getypos(), revive, robotslst, outFile);
                TRCptr->setRobot(map, turn->data->getName(), upgradesymbol, turn->data->getxpos(), turn->data->getypos(), revive, robotslst, outFile);

                Node<T>* upgraderobots = getNode(TRCptr);

                if(turn->next == nullptr)
                {
                    turn->next = upgraderobots;
                    upgraderobots->next = nullptr;
                    upgraderobots = nullptr;
                    turn = turn->next;
                    deleterobot(symbol);
                }
                else
                {
                    upgraderobots->next = turn->next;
                    turn->next = upgraderobots;
                    upgraderobots = nullptr;
                    turn = turn->next;
                    deleterobot(symbol);
                }
                cout << "RoboCop has upgraded to TerminatorRoboCop" << endl;
                outFile << "RoboCop has upgraded to TerminatorRoboCop" << endl;
            }
            else if(newsymbol == "%")
            {
                string upgradesymbol = "?";
                Robot *URptr = new UltimateRobot(URptr, demo1, map, turn->data->getName(), upgradesymbol, turn->data->getxpos(), turn->data->getypos(), revive, robotslst, outFile);
                URptr->setRobot(map, turn->data->getName(), upgradesymbol, turn->data->getxpos(), turn->data->getypos(), revive, robotslst, outFile);

                Node<T>* upgraderobots = getNode(URptr);

                if(turn->next == nullptr)
                {
                    turn->next = upgraderobots;
                    upgraderobots->next = nullptr;
                    upgraderobots = nullptr;
                    turn = turn->next;
                    deleterobot(symbol);
                }
                else
                {
                    upgraderobots->next = turn->next;
                    turn->next = upgraderobots;
                    upgraderobots = nullptr;
                    turn = turn->next;
                    deleterobot(symbol);
                }
                cout << "TerminatorRoboCop has upgraded to UltimateRobot" << endl;
                outFile << "TerminatorRoboCop has upgraded to UltimateRobot" << endl;
            }
            else if(newsymbol == "&")
            {
                string upgradesymbol = "0";
                Robot *RTptr = new RoboTank(RTptr, demo1, map, turn->data->getName(), upgradesymbol, turn->data->getxpos(), turn->data->getypos(), revive, robotslst, outFile);
                RTptr->setRobot(map, turn->data->getName(), upgradesymbol, turn->data->getxpos(), turn->data->getypos(), revive, robotslst, outFile);

                Node<T>* upgraderobots = getNode(RTptr);

                if(turn->next == nullptr)
                {
                    turn->next = upgraderobots;
                    upgraderobots->next = nullptr;
                    upgraderobots = nullptr;
                    turn = turn->next;
                    deleterobot(symbol);
                }
                else
                {
                    upgraderobots->next = turn->next;
                    turn->next = upgraderobots;
                    upgraderobots = nullptr;
                    turn = turn->next;
                    deleterobot(symbol);
                }
                cout << "Madbot has upgraded to RoboTank" << endl;
                outFile << "Madbot has upgraded to RoboTank" << endl;
            }
            else if(newsymbol == "0")
            {
                string upgradesymbol = "?";
                Robot *URptr = new UltimateRobot(URptr, demo1, map, turn->data->getName(), upgradesymbol, turn->data->getxpos(), turn->data->getypos(), revive, robotslst, outFile);
                URptr->setRobot(map, turn->data->getName(), upgradesymbol, turn->data->getxpos(), turn->data->getypos(), revive, robotslst, outFile);

                Node<T>* upgraderobots = getNode(URptr);

                if(turn->next == nullptr)
                {
                    turn->next = upgraderobots;
                    upgraderobots->next = nullptr;
                    upgraderobots = nullptr;
                    turn = turn->next;
                    deleterobot(symbol);
                }
                else
                {
                    upgraderobots->next = turn->next;
                    turn->next = upgraderobots;
                    upgraderobots = nullptr;
                    turn = turn->next;
                    deleterobot(symbol);
                }
                cout << "RoboTank has upgraded to UltimateRobot" << endl;
                outFile << "RoboTank has upgraded to UltimateRobot" << endl;
            }
            
        }





        if(turn->next == nullptr)
        {
            symbol = head->data->getSymbol();
        }
        else
        {
            symbol = turn->next->data->getSymbol();
        }
        if(symbol == "@")
        {
            robot_type = "BlueThunder";
        }
        else if(symbol == "#")
        {
            robot_type = "Terminator";
        }
        else if(symbol == "$")
        {
            robot_type = "RoboCop";
        }
        else if(symbol == "%")
        {
            robot_type = "TerminatorRoboCop";
        }
        else if(symbol == "&")
        {
            robot_type = "Madbot";
        }
        else if(symbol == "0")
        {
            robot_type = "RoboTank";
        }
        else if(symbol == "?")
        {
            robot_type = "UltimateRobot";
        }



        
            int respawnstepsss;
            string respawnsymbol;
            string respawnname;
            if(respawnout == 1)
            {
                respawnstepsss = respawnstep1;
                respawnsymbol = respawnsymbol1;
                respawnname = respawnname1;
            }
            else if(respawnout == 2)
            {
                respawnstepsss = respawnstep2;
                respawnsymbol = respawnsymbol2;
                respawnname = respawnname2;
            }
            else if(respawnout == 3)
            {
                respawnstepsss = respawnstep3;
                respawnsymbol = respawnsymbol3;
                respawnname = respawnname3;
            }
            else if(respawnout == 4)
            {
                respawnstepsss = respawnstep4;
                respawnsymbol = respawnsymbol4;
                respawnname = respawnname4;
            }
            if(respawnstepsss == step)
            {
                revive.pop();
                Node<T>* respawnrobot = respawnRobot(demo1, map, respawnsymbol, revive, robotslst, respawnname, outFile);
                if(turn->next == nullptr)
                {
                    turn->next = respawnrobot;
                    respawnrobot->next = nullptr;
                    respawnrobot = nullptr;
                }
                else
                {
                    respawnrobot->next = turn->next;
                    turn->next = respawnrobot;
                    respawnrobot = nullptr;
                }
                
                if(respawnsymbol == "@")
                {
                    robot_type = "BlueThunder";
                }
                else if(respawnsymbol == "#")
                {
                    robot_type = "Terminator";
                }
                else if(respawnsymbol == "$")
                {
                    robot_type = "RoboCop";
                }
                else if(respawnsymbol == "%")
                {
                    robot_type = "TerminatorRoboCop";
                }
                else if(respawnsymbol == "&")
                {
                    robot_type = "Madbot";
                }
                else if(respawnsymbol == "0")
                {
                    robot_type = "RoboTank";
                }
                else if(respawnsymbol == "?")
                {
                    robot_type = "UltimateRobot";
                }
                cout << robot_type << " has respawn !!!" << endl;
                outFile << robot_type << " has respawn !!!" << endl;

                respawnout++;
                if (respawnout == 5)
                {
                    respawnout = 1;
                }
            }
        if(step == demo1.getrobotStep())
        {
            cout << "End Of Program";
            outFile << "End Of Program";
            cout << endl << endl;
            outFile << endl << endl;
        }
        else
        {
            cout << "The next robot is " << robot_type;
            outFile << "The next robot is " << robot_type;
            cout << endl << endl << endl;
            outFile << endl << endl << endl;
        }
        turn = turn->next;
        step++;
        if(turn == nullptr)
        {
            turn = head;
        }
    }
}

template <class T>
void LinkedList<T>::deleteallptr()
{
    Node<T>* turn = head;
    while(turn != nullptr)
    {
        Node<T>* temp = turn;
        turn = turn->next;
        delete temp;
    }
    head = nullptr;
}

template <class T>
string LinkedList<T>::getrobotname(string symbol)
{
    Node<T>* find = head;
    while(find->data->getSymbol() != symbol)
    {
        find = find->next;
    }
    return find->data->getName();
}

template <class T>
int LinkedList<T>::getStep()
{
    return step;
}

template <class T>
void LinkedList<T>::setRespawn(ReadFile &demo1, Battlefield &map, string symbol, Queue &revive, LinkedList<Robot*> &robotslst, string name, ofstream &outFile)
{
    //respawn = true;
    if(respawnin == 1)
    {
        respawnstep1 = step + 3;
        respawnsymbol1 = symbol;
        respawnname1 = name;
    }
    else if(respawnin == 2)
    {
        respawnstep2 = step + 3;
        respawnsymbol2 = symbol;
        respawnname2 = name;
    }
    else if(respawnin == 3)
    {
        respawnstep3 = step + 3;
        respawnsymbol3 = symbol;
        respawnname3 = name;
    }
    else if(respawnin == 4)
    {
        respawnstep4 = step + 3;
        respawnsymbol4 = symbol;
        respawnname4 = name;
    }
    respawnin++;
    if (respawnin == 5)
    {
        respawnin = 1;
    }
}

template <class T>
Node<T>* LinkedList<T>::respawnRobot(ReadFile &demo1, Battlefield &map, string symbol, Queue &revive, LinkedList<Robot*> &robotslst, string name, ofstream &outFile)
{
        // respawnsymbol = "";
        // respawnname = "";
        // respawn = false;
        // respawnstep = 0;
        if(symbol == "@")
        {
            int x = rand() % demo1.getPositionM();
            int y = rand() % demo1.getPositionN();
            Robot *BTptr = new BlueThunder(BTptr, demo1, map, name, symbol, x, y, revive, robotslst, outFile);
            BTptr->setRobot(map, name, symbol, x, y, revive, robotslst, outFile);

            Node<T>* respawnrobot = getNode(BTptr);
            return respawnrobot;
        }
        else if(symbol == "#")
        {
            int x = rand() % demo1.getPositionM();
            int y = rand() % demo1.getPositionN();
            Robot *Tptr = new Terminator(Tptr, demo1, map, name, symbol, x, y, revive, robotslst, outFile);
            Tptr->setRobot(map, name, symbol, x, y, revive, robotslst, outFile);

            Node<T>* respawnrobot = getNode(Tptr);
            return respawnrobot;
        }
        else if(symbol == "$")
        {
            int x = rand() % demo1.getPositionM();
            int y = rand() % demo1.getPositionN();
            Robot *RCptr = new RoboCop(RCptr, demo1, map, name, symbol, x, y, revive, robotslst, outFile);
            RCptr->setRobot(map, name, symbol, x, y, revive, robotslst, outFile);

            Node<T>* respawnrobot = getNode(RCptr);
            return respawnrobot;
        }
        else if(symbol == "%")
        {
            int x = rand() % demo1.getPositionM();
            int y = rand() % demo1.getPositionN();
            Robot *TRCptr = new TerminatorRoboCop(TRCptr, demo1, map, name, symbol, x, y, revive, robotslst, outFile);
            TRCptr->setRobot(map, name, symbol, x, y, revive, robotslst, outFile);

            Node<T>* respawnrobot = getNode(TRCptr);
            return respawnrobot;
        }
        else if(symbol == "&")
        {
            int x = rand() % demo1.getPositionM();
            int y = rand() % demo1.getPositionN();
            Robot *Mptr = new Madbot(Mptr, demo1, map, name, symbol, x, y, revive, robotslst, outFile);
            Mptr->setRobot(map, name, symbol, x, y, revive, robotslst, outFile);

            Node<T>* respawnrobot = getNode(Mptr);
            return respawnrobot;
        }
        else if(symbol == "0")
        {
            int x = rand() % demo1.getPositionM();
            int y = rand() % demo1.getPositionN();
            Robot *RTptr = new RoboTank(RTptr, demo1, map, name, symbol, x, y, revive, robotslst, outFile);
            RTptr->setRobot(map, name, symbol, x, y, revive, robotslst, outFile);

            Node<T>* respawnrobot = getNode(RTptr);
            return respawnrobot;
        }
        else
        {
            int x = rand() % demo1.getPositionM();
            int y = rand() % demo1.getPositionN();
            Robot *URptr = new UltimateRobot(URptr, demo1, map, name, symbol, x, y, revive, robotslst, outFile);
            URptr->setRobot(map, name, symbol, x, y, revive, robotslst, outFile);

            Node<T>* respawnrobot = getNode(URptr);
            return respawnrobot;
        }    
}

template class LinkedList<Robot*>;


/**********|**********|**********|
Program: Battlefield.h
Course: CCP6124-OOPDS
Trimester: 2410
Name: VINCENT OONG ZHU PEW
ID: 1211109755
Email: 1211109755@student.mmu.edu.my
Phone: 018-2891578
Name: SHANTANA VENKEDESWAR A/L KARTHEGESU
ID: 1201103447
Email: 1201103447@student.mmu.edu.my
Phone: 012-3225265
Lecture Section: TC2L
Tutorial Section: TT6L
**********|**********|**********/

#pragma once

#include <iostream>
#include <string>
#include <list>
#include <fstream>
using namespace std;

class Battlefield
{
    private:
        int width = 0;
        int height = 0;
        char **matrix;
        list<string> robotsPosition;   // sir can you overlook this list we really dont have enough time to change this 
    public:                            // our group is just two members and we couldn't think of any other way to solve this
        Battlefield(int positionM, int positionN);        // we only use list for this one small attribute in the whole program
        ~Battlefield();
        void displayinitial(ofstream &outFile);
        void display(string symbol, int xpos, int ypos, ofstream &outFile);
        void setrobotsPosition(string symbol, int xpos, int ypos);
        void moving(int position_x, int position_y, string symbol);
        bool shooting(int xshoot, int yshoot, string symbol);
        bool seeing(int new_x, int new_y, string symbol);
        bool checking(int new_x, int new_y, string symbol);
        void removePrevious(int x, int y);
        void removeShots();
        char getRobot(int x, int y);
        void removeRobots(char robot);
        void color(int color_value);
};
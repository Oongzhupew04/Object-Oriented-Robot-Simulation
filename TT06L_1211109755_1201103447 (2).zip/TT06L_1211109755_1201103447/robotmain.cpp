/**********|**********|**********|
Program: robotmain.cpp
Course: CCP6124-OOPDS
Trimester: 2410
Name: VINCENT OONG ZHU PEW
ID: 1211109755
Email: 1211109755@student.mmu.edu.my
Phone: 018-2891578
Name: SHANTANA VENKEDESWAR A/L KARTHEGESU
ID: 1201103447
Email: 1201103447@student.mmu.edu.my
Phone: 012-3225265
Lecture Section: TC2L
Tutorial Section: TT6L
**********|**********|**********/

#include <iostream>
using namespace std;
#include <fstream>
#include <string>
#include <sstream>
#include <iterator>
#include <cstdlib>
#include <ctime>
#include "ReadFile.h"
#include "Battlefield.h"
#include "LinkedList.h"
#include "Queue.h"
#include "Robot.h"
#include "SeeingRobot.h"
#include "ShootingRobot.h"
#include "SteppingRobot.h"
#include "MovingRobot.h"
#include "TeleportingRobot.h"
#include "RoboCop.h"
#include "Terminator.h"
#include "BlueThunder.h"
#include "TerminatorRoboCop.h"
#include "Madbot.h"
#include "RoboTank.h"
#include "UltimateRobot.h"


int main()
{
    string input = "input1.txt";
    ifstream inputFile(input);
    if (!inputFile) {
        cerr << "Error opening file." << endl;
        return 1;
    }

    ofstream outFile("output.txt");
    if (!outFile.is_open()) 
    {
        std::cerr << "Error: Could not open the file for writing." << std::endl;
        return 1;
    }
    ReadFile demo1(outFile, input);
    Battlefield map(demo1.getPositionM(), demo1.getPositionN());
    LinkedList<Robot*> robotslst;
    Queue revive(demo1.getrobotNumber());
    srand(time(0));

    string line;
    while (getline(inputFile, line)) 
    {
        if (line.find("M by N") != string::npos || line.find("steps:") != string::npos || line.find("robots:") != string::npos) {
            continue; // Skip this line
        }
        
        string R = line;
        stringstream ss(R);
        string type;
        string name;
        string randomM;
        string randomN;
        int M;
        int N;


        ss >> type >> name >> randomM >> randomN;
        if(randomM == "random" && randomN == "random")
        {
            M = rand() % (demo1.getPositionM() + 1);
            N = rand() % (demo1.getPositionN() + 1);
        }
        else
        {
            M = stoi(randomM);
            N = stoi(randomN);

        }
        if(type == "BlueThunder")  
        {
            string symbol = "@";
            Robot *BTptr = new BlueThunder(BTptr, demo1, map, name, symbol, M, N, revive, robotslst, outFile);
            BTptr->setRobot(map, name, symbol, M, N, revive, robotslst, outFile);
            robotslst.push_back(BTptr);
        }
        else if(type == "Terminator")
        {
            string symbol = "#";
            Robot *Tptr = new Terminator(Tptr, demo1, map, name, symbol, M, N, revive, robotslst, outFile);
            Tptr->setRobot(map, name, symbol, M, N, revive, robotslst, outFile);
            robotslst.push_back(Tptr);
        }
        else if(type == "RoboCop")
        {
            string symbol = "$";
            Robot *RCptr = new RoboCop(RCptr, demo1, map, name, symbol, M, N, revive, robotslst, outFile);
            RCptr->setRobot(map, name, symbol, M, N, revive, robotslst, outFile);
            robotslst.push_back(RCptr);
        }
        else if(type == "TerminatorRoboCop")
        {
            string symbol = "%";
            Robot *TRCptr = new TerminatorRoboCop(TRCptr, demo1, map, name, symbol, M, N, revive, robotslst, outFile);
            TRCptr->setRobot(map, name, symbol, M, N, revive, robotslst, outFile);
            robotslst.push_back(TRCptr);
        }
        else if(type == "Madbot")
        {
            string symbol = "&";
            Robot *Mptr = new Madbot(Mptr, demo1, map, name, symbol, M, N, revive, robotslst, outFile);
            Mptr->setRobot(map, name, symbol, M, N, revive, robotslst, outFile);
            robotslst.push_back(Mptr);
        }
        else if(type == "RoboTank")
        {
            string symbol = "0";
            Robot *RTptr = new RoboTank(RTptr, demo1, map, name, symbol, M, N, revive, robotslst, outFile);
            RTptr->setRobot(map, name, symbol, M, N, revive, robotslst, outFile);
            robotslst.push_back(RTptr);
        }
        else if(type == "UltimateRobot")
        {
            string symbol = "?";
            Robot *URptr = new UltimateRobot(URptr, demo1, map, name, symbol, M, N, revive, robotslst, outFile);
            URptr->setRobot(map, name, symbol, M, N, revive, robotslst, outFile);
            robotslst.push_back(URptr);
        }
    }

    for(int i = 0; i < 1; i++)
    {
        cout << "STEP: 0" << endl;
        outFile << "STEP: 0" << endl;
        map.displayinitial(outFile);
        cout << endl << endl;
        outFile << endl << endl;
    }
    
    robotslst.print(demo1, map, revive, robotslst, outFile);


    robotslst.deleteallptr();
    robotslst.~LinkedList();
    map.~Battlefield();
    revive.~Queue();
    inputFile.close();
    outFile.close();
    return 0;
}


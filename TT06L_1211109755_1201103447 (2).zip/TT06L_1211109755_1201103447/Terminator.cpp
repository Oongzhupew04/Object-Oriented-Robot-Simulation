/**********|**********|**********|
Program: Terminator.cpp
Course: CCP6124-OOPDS
Trimester: 2410
Name: VINCENT OONG ZHU PEW
ID: 1211109755
Email: 1211109755@student.mmu.edu.my
Phone: 018-2891578
Name: SHANTANA VENKEDESWAR A/L KARTHEGESU
ID: 1201103447
Email: 1201103447@student.mmu.edu.my
Phone: 012-3225265
Lecture Section: TC2L
Tutorial Section: TT6L
**********|**********|**********/

#include "Terminator.h"
#include "Battlefield.h"
#include "LinkedList.h"
#include "ReadFile.h"
#include "Robot.h"
#include "Queue.h"
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

void Terminator::see(Robot* &botptr, ReadFile &demo1, Battlefield &map, string symbol, int x, int y, Queue &revive, LinkedList<Robot*> &robotslst, ofstream &outFile)
{
    bool enemy_found = false;
    int enemy_x = -1, enemy_y = -1;

        // Scan 3x3 area around the robot for enemies
        for (int n = -1; n <= 1; n++) 
        {
            for (int i = -1; i <= 1; i++) 
            {
                int new_y = y + n;
                int new_x = x + i;

                // Skip the robot's own position or out-of-bounds positions
                if ((n == 0 && i == 0) || new_y < 0 || new_x < 0 || new_y >= demo1.getPositionM() || new_x >= demo1.getPositionN()) 
                {
                    continue;
                }

                enemy_found = map.seeing(new_x, new_y, symbol);

                if (enemy_found) 
                {
                    enemy_x = new_x;
                    enemy_y = new_y;
                    botptr->setenemy_x(enemy_x);
                    botptr->setenemy_y(enemy_y);
                    cout << "Terminator (" << botptr->getName() << ") saw an enemy at position " << enemy_x << "," << enemy_y << endl;
                    outFile << "Terminator (" << botptr->getName() << ") saw an enemy at position " << enemy_x << "," << enemy_y << endl;
                    step(botptr, demo1, map, symbol, enemy_x, enemy_y, revive, robotslst, outFile); 
                    break; // Stop searching once an enemy is found
                }            
            }
            if (enemy_found) 
            {
                break; // Stop searching once an enemy is found
            }
        }
        if(enemy_found == false)
        {
            cout << "Terminator (" << botptr->getName() << ") saw no enemies at surrounding" << endl;
            outFile << "Terminator (" << botptr->getName() << ") saw no enemies at surrounding" << endl;
            move(botptr, demo1, map, symbol, x, y, revive, robotslst, outFile);
        } 
}

void Terminator::move(Robot* &botptr, ReadFile &demo1, Battlefield &map, string symbol, int x, int y, Queue &revive, LinkedList<Robot*> &robotslst, ofstream &outFile)
{
    int position_x = x;
    int position_y = y;
    int rows = demo1.getPositionM();
    int cols = demo1.getPositionN();

    bool valid_move = false;
        while (!valid_move)
        {
            int random_number = rand() % 8 + 1;
            switch (random_number) 
            {
                case 1:
                    if (position_y > 0)
                    {
                        position_y--;
                        valid_move = true;
                    }
                    break;
                case 2:
                    if (position_y < rows - 1)
                    {
                        position_y++;
                        valid_move = true;
                    }
                    break;
                case 3:
                    if (position_x < cols - 1)
                    {
                        position_x++;
                        valid_move = true;
                    }
                    break;
                case 4:
                    if (position_x > 0)
                    {
                        position_x--;
                        valid_move = true;
                    }
                    break;
                case 5:
                    if (position_y > 0 && position_x < cols - 1)
                    {
                        position_y--; 
                        position_x++;
                        valid_move = true;
                    }
                    break;
                case 6:
                    if (position_y > 0 && position_x > 0)
                    {
                        position_y--; 
                        position_x--;
                        valid_move = true;
                    }
                    break;
                case 7:
                    if (position_y < rows - 1 && position_x < cols - 1)
                    {
                        position_y++; 
                        position_x++;
                        valid_move = true;
                    }
                    break;
                default:
                    if (position_y < rows - 1 && position_x > 0)
                    {
                        position_y++; 
                        position_x--;
                        valid_move = true;
                    }
                    break;
            }
        }
        map.moving(position_x, position_y, symbol);
        map.removePrevious(x, y);
        botptr->updatePosition(position_x, position_y);
        cout << "Terminator (" << botptr->getName() << ") moves to position " << position_x << "," << position_y << endl;
        outFile << "Terminator (" << botptr->getName() << ") moves to position " << position_x << "," << position_y << endl;
}

void Terminator::step(Robot* &botptr, ReadFile &demo1, Battlefield &map, string symbol, int x, int y, Queue &revive, LinkedList<Robot*> &robotslst, ofstream &outFile)
{
    int position_x = x;
    int position_y = y;
    char robot = map.getRobot(position_x, position_y);
    map.moving(position_x, position_y, symbol);
    revive.removeDeadRobot(demo1, map, robot, revive, robotslst, outFile);
    botptr->updateKill();
    botptr->setenemy_x(0);
    botptr->setenemy_y(0);
    cout << "Number of kills: " << botptr->getNumKill() << endl;
    outFile << "Number of kills: " << botptr->getNumKill() << endl;
    map.removePrevious(botptr->getxpos(), botptr->getypos());
    botptr->updatePosition(position_x, position_y);
    cout << "Terminator (" << botptr->getName() << ") steps on a robot at position " << position_x << "," << position_y << endl;
    outFile << "Terminator (" << botptr->getName() << ") steps on a robot at position " << position_x << "," << position_y << endl;
}

void Terminator::action(Robot* &botptr, ReadFile &demo1, Battlefield &map, string symbol, int x, int y, Queue &revive, LinkedList<Robot*> &robotslst, ofstream &outFile)
{
    map.removeShots();
    see(botptr, demo1, map, symbol, x, y, revive, robotslst, outFile);
}
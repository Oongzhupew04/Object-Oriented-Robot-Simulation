/**********|**********|**********|
Program: LinkedList.h
Course: CCP6124-OOPDS
Trimester: 2410
Name: VINCENT OONG ZHU PEW
ID: 1211109755
Email: 1211109755@student.mmu.edu.my
Phone: 018-2891578
Name: SHANTANA VENKEDESWAR A/L KARTHEGESU
ID: 1201103447
Email: 1201103447@student.mmu.edu.my
Phone: 012-3225265
Lecture Section: TC2L
Tutorial Section: TT6L
**********|**********|**********/

#pragma once

#include <iostream>
#include <string>
#include <fstream>
#include "Robot.h"
#include "ReadFile.h"

using namespace std;

template <class T>
class LinkedList;
class Robot;
class Queue;

template<class T>
    struct Node
    {
        T data;
        Node* next;
    };

template<class T>
class LinkedList
{
    Node<T>* head;
    int step = 1;
    int respawnout = 1;
    int respawnin = 1;
    int respawnstep1, respawnstep2, respawnstep3, respawnstep4;
    string respawnsymbol1, respawnsymbol2, respawnsymbol3, respawnsymbol4;
    string respawnname1, respawnname2, respawnname3, respawnname4;


    public:
    LinkedList();
    ~LinkedList();

    void push_back(T value);

    Node<T>* getNode(T value);

    void deleterobot(string symbol);

    Node<T>* getEnd();
    
    void print(ReadFile &demo1, Battlefield &map, Queue &revive, LinkedList<Robot*> &robotslst, ofstream &outFile);

    void deleteallptr();

    string getrobotname(string symbol);

    int getStep();

    void setRespawn(ReadFile &demo1, Battlefield &map, string symbol, Queue &revive, LinkedList<Robot*> &robotslst, string name, ofstream &outFile);

    Node<T>* respawnRobot(ReadFile &demo1, Battlefield &map, string symbol, Queue &revive, LinkedList<Robot*> &robotslst, string name, ofstream &outFile);

};



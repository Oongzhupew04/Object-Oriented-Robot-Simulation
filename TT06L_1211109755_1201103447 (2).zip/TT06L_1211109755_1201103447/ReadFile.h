/**********|**********|**********|
Program: ReadFile.h
Course: CCP6124-OOPDS
Trimester: 2410
Name: VINCENT OONG ZHU PEW
ID: 1211109755
Email: 1211109755@student.mmu.edu.my
Phone: 018-2891578
Name: SHANTANA VENKEDESWAR A/L KARTHEGESU
ID: 1201103447
Email: 1201103447@student.mmu.edu.my
Phone: 012-3225265
Lecture Section: TC2L
Tutorial Section: TT6L
**********|**********|**********/

#pragma once

#include <iostream>
using namespace std;
#include <fstream>
#include <string>
#include <sstream>
#include <iterator>

class ReadFile
{
public:
    ifstream input;
    int positionM;
    int positionN;
    int MxN;
    int robotStep;
    int robotNumber;
    string robotType;
    string robotName;
    string robotPosM;
    string robotPosN;
    string type;
    string name;
    string posX;
    string posY;

    void setrobotNumber(int bot) { robotNumber = bot; }
    void setrobotStep(int step) { robotStep = step; }
    void setPositionM(int M) { positionM = M; }
    void setPositionN(int N) { positionN = N; }
    int getPositionM() { return positionM; }
    int getPositionN() { return positionN; }
    int getrobotNumber() { return robotNumber; }
    int getrobotStep() { return robotStep; }

    void setMxN(int M, int N) {MxN = M * N;}
    int getMxN() { return MxN; }

    ReadFile(ofstream &outFile, string inputs);
};
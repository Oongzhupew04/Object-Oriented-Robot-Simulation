/**********|**********|**********|
Program: Battlefield.cpp
Course: CCP6124-OOPDS
Trimester: 2410
Name: VINCENT OONG ZHU PEW
ID: 1211109755
Email: 1211109755@student.mmu.edu.my
Phone: 018-2891578
Name: SHANTANA VENKEDESWAR A/L KARTHEGESU
ID: 1201103447
Email: 1201103447@student.mmu.edu.my
Phone: 012-3225265
Lecture Section: TC2L
Tutorial Section: TT6L
**********|**********|**********/

#include "Battlefield.h"
#include <list>
#include <sstream>
#include <string>

using namespace std;

Battlefield::Battlefield(int positionM, int positionN):width(positionM), height(positionN)
{
    matrix = new char*[height];
    for(int i = 0; i < height; ++i)
    {
        matrix[i] = new char[width];
        for(int j = 0; j < width; ++j)
        {
            matrix[i][j] = '.';
        }
    }
}

Battlefield::~Battlefield()
{
    {
        for(int i = 0; i < height; ++i)
            {
                delete[] matrix[i];
            }
        delete[] matrix;
    }
}

void Battlefield::displayinitial(ofstream &outFile)
{
    {
        for (int i = 0; i < height; ++i)
        {
            for (int j = 0; j < width; ++j)
            {
                for (const auto &POS : robotsPosition)
                {
                    int x;
                    int y;
                    string symbol;
                    stringstream ss(POS);
                    ss >> symbol >> x >> y;
                    if((x) == j && (y) == i)
                    {
                        matrix[i][j] = symbol[0];
                    }
                }

                switch (matrix[i][j]) 
                {
                    case '@':
                        color(0x0b); // Blue
                        break;
                    case '#':
                        color(0x0e); // Yellow
                        break;
                    case '$':
                        color(0x0c); // Red
                        break;
                    case '%':
                        color(0x0f); // Cyan
                        break;
                    case '&':
                        color(0x0d); // Magenta
                        break;
                    case '0':
                        color(0x07); // White
                        break;
                    case '?':
                        color(0x09); // Black
                        break;
                    case '.':
                        color(0x0a); // Green
                        break;
                    default:
                        color(0x07); // White
                        break;
                }
                cout << matrix[i][j] << ' ';
                outFile << matrix[i][j] << ' ';
            }
            cout << endl;
            outFile << endl;
        }
        color(0x07);
    }
}

void Battlefield::display(string symbol, int xpos, int ypos, ofstream &outFile)
{
        for (int i = 0; i < height; ++i)
        {
            for (int j = 0; j < width; ++j)
            {
                if((xpos) == j && (ypos) == i)
                {
                    matrix[i][j] = symbol[0];
                }

                switch (matrix[i][j]) 
                {
                    case '@':
                        color(0x0b); // Blue
                        break;
                    case '#':
                        color(0x0e); // Yellow
                        break;
                    case '$':
                        color(0x0c); // Red
                        break;
                    case '%':
                        color(0x0f); // Cyan
                        break;
                    case '&':
                        color(0x0d); // Magenta
                        break;
                    case '0':
                        color(0x07); // White
                        break;
                    case '?':
                        color(0x09); // Black
                        break;
                    case '.':
                        color(0x0a); // Green
                        break;
                    default:
                        color(0x07); // White
                        break;
                }
                cout << matrix[i][j] << ' ';
                outFile << matrix[i][j] << ' ';
            }
            cout << endl;
            outFile << endl;
        }
        color(0x07);
    
}

void Battlefield::setrobotsPosition(string symbol, int xpos, int ypos)
{
    string a = symbol+" "+to_string(xpos)+" "+to_string(ypos);
    robotsPosition.push_back(a);
}

void Battlefield::moving(int position_x, int position_y, string symbol)
{
    char symbo = symbol[0];
    matrix[position_y][position_x] = symbo;
}

bool Battlefield::shooting(int xshoot, int yshoot, string symbol)
{
    if (matrix[yshoot][xshoot] != '.' && matrix[yshoot][xshoot] != symbol[0] && matrix[yshoot][xshoot] != '*') 
        {
            matrix[yshoot][xshoot] = '*';
            return true;
        } 
        else 
        {
            matrix[yshoot][xshoot] = '*';
            return false;
        }
}

bool Battlefield::seeing(int new_x, int new_y, string symbol)
{
    // Check if the current position has an enemy
                if (matrix[new_y][new_x] != symbol[0] && matrix[new_y][new_x] != '.' && matrix[new_y][new_x] != '*') 
                {
                    return true;
                }
                else
                {
                    return false;
                }
}

bool Battlefield::checking(int new_x, int new_y, string symbol)
{
    if (matrix[new_y][new_x] != symbol[0] && matrix[new_y][new_x] != '.' && matrix[new_y][new_x] != '*') 
                {
                    return true;
                }
                else
                {
                    return false;
                }
}

void Battlefield::removePrevious(int x, int y)
{
        for (int i = 0; i < height; ++i)
        {
            for (int j = 0; j < width; ++j)
            {
                if(j == x && i == y)
                {
                    matrix[i][j] = '.';
                }
            }
        }
}

void Battlefield::removeShots()
{
        for (int i = 0; i < height; ++i)
        {
            for (int j = 0; j < width; ++j)
            {
                if(matrix[i][j] == '*')
                {
                    matrix[i][j] = '.';
                }
                else
                {

                }
            }
        }
}


char Battlefield::getRobot(int x, int y)
{
        for (int i = 0; i < height; ++i)
        {
            for (int j = 0; j < width; ++j)
            {
                if(j == x && i == y)
                {
                    return matrix[i][j];
                }
            }
        }
        return '\0';
}

void Battlefield::removeRobots(char robot)
{
        for (int i = 0; i < height; ++i)
        {
            for (int j = 0; j < width; ++j)
            {
                if(matrix[i][j] == robot)
                {
                    matrix[i][j] = '.';
                }
                else
                {

                }
            }
        }
}

// bool Battlefield::avoidItself(int xshoot, int yshoot, string symbol)   // For bombing
// {
//     for (int i = yshoot - 1; i <= yshoot + 1; i++) 
//     {
//         for (int j = xshoot - 1; j <= xshoot + 1; j++) 
//         {
//             if (matrix[yshoot][xshoot] == symbol[0]) 
//             {
//                 return true;
//             }
//             else
//             {
//                 return false;
//             }
//         }
//     }
// }

// list<char> Battlefield::check(int xshoot, int yshoot, string symbol)
// {
//     list<char> bots;
//     for (int i = yshoot - 1; i <= yshoot + 1; i++) 
//     {
//         for (int j = xshoot - 1; j <= xshoot + 1; j++) 
//         {
//             if (matrix[yshoot][xshoot] != '.' && matrix[yshoot][xshoot] != symbol[0] && matrix[yshoot][xshoot] != '*') 
//             {
//                 bots.push_back(matrix[yshoot][xshoot]);
//             }
//         }
//     }
//     return bots;
// }

void Battlefield::color(int color_value)
{
    switch (color_value) {
        case 0x0b:
            cout << "\033[34m"; // Blue
            break;
        case 0x0a:
            cout << "\033[32m"; // Green
            break;
        case 0x0c:
            cout << "\033[31m"; // Red
            break;
        case 0x0e:
            cout << "\033[33m"; // Yellow
            break;
        case 0x0d:
            cout << "\033[35m"; // Magenta
            break;
        case 0x0f:
            cout << "\033[36m"; // Cyan
            break;
        case 0x09:
            cout << "\033[30m"; // Black
            break;
        case 0x07:
            cout << "\033[37m"; // White
            break;
            cout << "\033[0m";  // Reset to default color
            break;
    }
}
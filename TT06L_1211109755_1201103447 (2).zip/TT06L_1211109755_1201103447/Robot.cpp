/**********|**********|**********|
Program: Robot.cpp
Course: CCP6124-OOPDS
Trimester: 2410
Name: VINCENT OONG ZHU PEW
ID: 1211109755
Email: 1211109755@student.mmu.edu.my
Phone: 018-2891578
Name: SHANTANA VENKEDESWAR A/L KARTHEGESU
ID: 1201103447
Email: 1201103447@student.mmu.edu.my
Phone: 012-3225265
Lecture Section: TC2L
Tutorial Section: TT6L
**********|**********|**********/

#include "Robot.h"
#include "Battlefield.h"
#include "ReadFile.h"
#include "Queue.h"
#include "LinkedList.h"
using namespace std;

Robot::Robot()
{
    name = "X";
    xpos = 0;
    ypos = 0;
    symbol = " ";
}

Robot::Robot(Robot* &botptr, ReadFile &demo1, Battlefield &map, string name, string symbol, int x, int y, Queue &revive, LinkedList<Robot*> &robotslst, ofstream &outFile)
{
    this->name = name;
    this->symbol = symbol;
    this->xpos = x;
    this->ypos = y;
}

void Robot::setRobot(Battlefield &map, string name, string symbol, int x, int y, Queue &revive, LinkedList<Robot*> &robotslst, ofstream &outFile)
{
    this->name = name;
    this->symbol = symbol;
    this->xpos = x;
    this->ypos = y;
    map.setrobotsPosition(symbol, xpos, ypos);
}

string Robot::getName()
{
    return name;
}

string Robot::getSymbol()
{
    return symbol;
}

int Robot::getxpos()
{
    return xpos;
}

int Robot::getypos()
{
    return ypos;
}

void Robot::updatePosition(int position_x, int position_y)
{
    this->xpos = position_x;
    this->ypos = position_y;
}

void Robot::updateKill()
{
    this->howManyKill++;
}

int Robot::getNumKill()
{
    return howManyKill;
}

int Robot::getBlueThunderCount()
{
    return BlueThunderCount;
}

void Robot::setBlueThunderCount(int i)
{
    this->BlueThunderCount = i;
}

void Robot::setenemy_x(int enemyx)
{
    this->enemy_x = enemyx;
}

int Robot::getenemy_x()
{
    return enemy_x;
}

void Robot::setenemy_y(int enemyy)
{
    this->enemy_y = enemyy;
}

int Robot::getenemy_y()
{
    return enemy_y;
}

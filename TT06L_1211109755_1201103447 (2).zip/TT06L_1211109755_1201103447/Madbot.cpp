/**********|**********|**********|
Program: Madbot.cpp
Course: CCP6124-OOPDS
Trimester: 2410
Name: VINCENT OONG ZHU PEW
ID: 1211109755
Email: 1211109755@student.mmu.edu.my
Phone: 018-2891578
Name: SHANTANA VENKEDESWAR A/L KARTHEGESU
ID: 1201103447
Email: 1201103447@student.mmu.edu.my
Phone: 012-3225265
Lecture Section: TC2L
Tutorial Section: TT6L
**********|**********|**********/

#include "Madbot.h"
using namespace std;

void Madbot::shoot(Robot* &botptr, ReadFile &demo1, Battlefield &map, string symbol, int x, int y, Queue &revive, LinkedList<Robot*> &robotslst, ofstream &outFile)
{
    int xshoot = botptr->getxpos();
    int yshoot = botptr->getypos();
    bool B = false;
    while((xshoot == botptr->getxpos() && yshoot == botptr->getypos()) || xshoot > (x+1) || xshoot < (x-1) || yshoot > (y+1) || yshoot < (y-1))
    {
        xshoot = rand() % (demo1.getPositionM()-1);
        yshoot = rand() % (demo1.getPositionN()-1); 
    }

    char robot = map.getRobot(xshoot, yshoot);
    B = map.shooting(xshoot, yshoot, symbol);
    cout << "Madbot (" << botptr->getName() << ") shoots at position " << xshoot << "," << yshoot << endl;
    outFile << "Madbot (" << botptr->getName() << ") shoots at position " << xshoot << "," << yshoot << endl;
    if(B == true)
    {
        revive.removeDeadRobot(demo1, map, robot, revive, robotslst, outFile);
        botptr->updateKill();
        botptr->setenemy_x(0);
        botptr->setenemy_y(0);
        cout << "Number of kills: " << botptr->getNumKill() << endl;
        outFile << "Number of kills: " << botptr->getNumKill() << endl;
    }
}

void Madbot::action(Robot* &botptr, ReadFile &demo1, Battlefield &map, string symbol, int x, int y, Queue &revive, LinkedList<Robot*> &robotslst, ofstream &outFile)
{
    map.removeShots();
    shoot(botptr, demo1, map, symbol, x, y, revive, robotslst, outFile);
}
/**********|**********|**********|
Program: BlueThunder.cpp
Course: CCP6124-OOPDS
Trimester: 2410
Name: VINCENT OONG ZHU PEW
ID: 1211109755
Email: 1211109755@student.mmu.edu.my
Phone: 018-2891578
Name: SHANTANA VENKEDESWAR A/L KARTHEGESU
ID: 1201103447
Email: 1201103447@student.mmu.edu.my
Phone: 012-3225265
Lecture Section: TC2L
Tutorial Section: TT6L
**********|**********|**********/

#include "BlueThunder.h"

using namespace std;

void BlueThunder::shoot(Robot* &botptr, ReadFile &demo1, Battlefield &map, string symbol, int x, int y, Queue &revive, LinkedList<Robot*> &robotslst, ofstream &outFile)
{
    int i = botptr->getBlueThunderCount();
    int xshoot;
    int yshoot;
    bool B = false;
    int positions[8][2] = 
    {
        {x, y - 1},     // Top
        {x + 1, y - 1}, // Top-right
        {x + 1, y},     // Right
        {x + 1, y + 1}, // Bottom-right
        {x, y + 1},     // Bottom
        {x - 1, y + 1}, // Bottom-left
        {x - 1, y},     // Left
        {x - 1, y - 1}, // Top-left
    };

    xshoot = positions[i][0];
    yshoot = positions[i][1];
    i++;
    if(i == 8)
    {
        i = 0;
    }
    botptr->setBlueThunderCount(i);
    
    char robot = map.getRobot(xshoot, yshoot);
    B = map.shooting(xshoot, yshoot, symbol);
    cout << "BlueThunder (" << botptr->getName() << ") shoots at position " << xshoot << "," << yshoot << endl;
    outFile << "BlueThunder (" << botptr->getName() << ") shoots at position " << xshoot << "," << yshoot << endl;
    if(B == true)
    {
        revive.removeDeadRobot(demo1, map, robot, revive, robotslst, outFile);
        botptr->updateKill();
        botptr->setenemy_x(0);
        botptr->setenemy_y(0);
        cout << "Number of kills: " << botptr->getNumKill() << endl;
        outFile << "Number of kills: " << botptr->getNumKill() << endl;
    }
}

void BlueThunder::action(Robot* &botptr, ReadFile &demo1, Battlefield &map, string symbol, int x, int y, Queue &revive, LinkedList<Robot*> &robotslst, ofstream &outFile)
{
    map.removeShots();
    shoot(botptr, demo1, map, symbol, x, y, revive, robotslst, outFile);
}

/**********|**********|**********|
Program: Queue.h
Course: CCP6124-OOPDS
Trimester: 2410
Name: VINCENT OONG ZHU PEW
ID: 1211109755
Email: 1211109755@student.mmu.edu.my
Phone: 018-2891578
Name: SHANTANA VENKEDESWAR A/L KARTHEGESU
ID: 1201103447
Email: 1201103447@student.mmu.edu.my
Phone: 012-3225265
Lecture Section: TC2L
Tutorial Section: TT6L
**********|**********|**********/

#pragma once

#include <iostream>
#include <string>
//#include "LinkedList.h"

using namespace std;

template <class T>
class LinkedList;
class Robot;
class Battlefield;
class ReadFile;

class Queue
{
    int front, back, size, capacity;
    int BTlive = 3,Tlive = 3, RClive = 3, TRClive = 3, Mlive = 3, RTlive = 3, URlive = 3;
    char *queue;
    int step = 0;
    public:
    Queue(int c);
    ~Queue();
    bool full();
    bool empty();
    char first();
    void push(char robot);
    void pop();
    void removeDeadRobot(ReadFile &demo1, Battlefield &map, char robot, Queue &revive, LinkedList<Robot*> &robotslst, ofstream &outFile);
    void increaseStep();
};